
package com.example.springbootProject.employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 *
 * @author atsoupe bessou
 */
@Controller
public class EmployeeController {
    
    @GetMapping("/employee")  
    public String employeeStart(){
        return "employee"; //html
    
}
    @GetMapping("/orders")  
    public String ordersStart(){
        return "order"; //html
    
}
    @GetMapping("/tables")  
    public String tablesStart(){
        return "tables"; //html
    }
    
    @GetMapping("/information")  
    public String informationStart(){
        return "information"; //html
    }
    
}